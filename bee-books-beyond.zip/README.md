# Wistudy Books Collections

Your Ultimate Study Partner for Academic Excellence

## 🌟 Features

- **Professional Book Store**: Browse and purchase educational books
- **NPCE Materials**: Pharmacy technician certification past questions
- **Academic Services**: Term papers, seminars, and project development
- **Mobile Responsive**: Works perfectly on all devices
- **Fast & Secure**: Built with Next.js and deployed on Vercel

## 📚 What We Offer

### Books & Educational Materials
- Medical textbooks (Ross & Wilson Anatomy & Physiology)
- Business and leadership books
- History and cultural studies
- Digital and technology resources

### NPCE Past Questions
- Yearly collections (2018-2024)
- Subject-specific materials
- All major subjects covered
- Affordable pricing

### Academic Services
- Custom term paper writing
- Seminar presentations
- Complete project development
- Professional quality guaranteed

## 🚀 Technology Stack

- **Framework**: Next.js 14
- **Styling**: Tailwind CSS
- **Language**: TypeScript
- **Deployment**: Vercel
- **Icons**: Lucide React

## 📱 Contact

- **Email**: wistudybookscollections@gmail.com
- **Telegram**: [Join our group](https://t.me/+g_BCFCWVs9I5YWU0)
- **Website**: wistudy-books.vercel.app

## 🎯 Mission

To provide quality educational resources and academic support services to students and professionals, helping them achieve academic excellence and career success.

## 📄 License

© 2024 Wistudy Books Collections. All rights reserved.
\`\`\`

```text file="vercel.json"
{
  "version": 2,
  "builds": [
    {
      "src": "package.json",
      "use": "@vercel/next"
    }
  ],
  "routes": [
    {
      "src": "/ads.txt",
      "status": 301,
      "headers": {
        "Location": "https://srv.adstxtmanager.com/19390/wistudy-books.vercel.app"
      }
    }
  ]
}
