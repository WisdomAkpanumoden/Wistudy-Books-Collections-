import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatPrice(price: string): string {
  // Remove currency symbols and format consistently
  return price.replace(/[^\d.,]/g, "").trim()
}

export function generateEmailSubject(bookTitle: string): string {
  return `Purchase Request: ${bookTitle}`
}

export function generateEmailBody(bookTitle: string, author: string, price: string, originalPrice: string): string {
  return `Hi Wistudy Books Collections,

I want to purchase "${bookTitle}" by ${author} for the promotional price of ${price} (originally ${originalPrice}).

Please let me know the next steps for completing this purchase.

Thank you!`
}

export function createMailtoLink(bookTitle: string, author: string, price: string, originalPrice: string): string {
  const subject = encodeURIComponent(generateEmailSubject(bookTitle))
  const body = encodeURIComponent(generateEmailBody(bookTitle, author, price, originalPrice))
  return `mailto:wistudybookscollections@gmail.com?subject=${subject}&body=${body}`
}

export function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^\w\s-]/g, "")
    .replace(/[\s_-]+/g, "-")
    .replace(/^-+|-+$/g, "")
}

export function truncateText(text: string, maxLength: number): string {
  if (text.length <= maxLength) return text
  return text.slice(0, maxLength).trim() + "..."
}

export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

export function formatDate(date: Date): string {
  return new Intl.DateTimeFormat("en-US", {
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(date)
}
