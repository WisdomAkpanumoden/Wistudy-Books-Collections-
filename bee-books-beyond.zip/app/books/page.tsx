import { FeaturedBooks } from "@/components/featured-books"
import { SearchSection } from "@/components/search-section"

export default function BooksPage() {
  return (
    <main className="min-h-screen">
      <div className="bg-gradient-to-r from-blue-100 to-indigo-100 py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold text-blue-900 mb-4">Our Complete Book Collection</h1>
          <p className="text-xl text-blue-800">Explore our extensive library of approved books and exclusive titles</p>
        </div>
      </div>

      <SearchSection />

      <FeaturedBooks />
    </main>
  )
}
