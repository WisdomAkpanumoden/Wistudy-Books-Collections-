import { Card, CardContent } from "@/components/ui/card"
import { BookOpen, Users, Award, Target } from "lucide-react"

export default function AboutPage() {
  return (
    <main className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-100 to-purple-100 py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">About Wistudy Books Collections</h1>
          <p className="text-xl text-gray-700 max-w-3xl mx-auto">
            Your trusted partner in academic excellence, providing quality educational resources and professional
            services to students and professionals across Nigeria and beyond.
          </p>
        </div>
      </div>

      {/* Mission & Vision */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Mission</h2>
              <p className="text-gray-700 text-lg leading-relaxed mb-6">
                To democratize access to quality educational resources by providing affordable books, study materials,
                and academic services that empower students and professionals to achieve their educational goals.
              </p>
              <div className="flex items-center">
                <Target className="w-8 h-8 text-blue-600 mr-3" />
                <span className="text-gray-600">Empowering Education Through Accessibility</span>
              </div>
            </div>
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Vision</h2>
              <p className="text-gray-700 text-lg leading-relaxed mb-6">
                To become the leading educational resource provider in Nigeria, known for quality, affordability, and
                exceptional customer service in the academic community.
              </p>
              <div className="flex items-center">
                <Award className="w-8 h-8 text-purple-600 mr-3" />
                <span className="text-gray-600">Excellence in Educational Support</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* What We Offer */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">What We Offer</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center">
              <CardContent className="p-8">
                <BookOpen className="w-12 h-12 text-blue-600 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-gray-900 mb-4">Educational Books</h3>
                <p className="text-gray-600">
                  Comprehensive collection of textbooks, reference materials, and study guides across various
                  disciplines including medical, business, and technology.
                </p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-8">
                <Users className="w-12 h-12 text-green-600 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-gray-900 mb-4">NPCE Materials</h3>
                <p className="text-gray-600">
                  Complete pharmacy technician certification materials including past questions, subject-specific
                  guides, and preparation resources.
                </p>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-8">
                <Award className="w-12 h-12 text-purple-600 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-gray-900 mb-4">Academic Services</h3>
                <p className="text-gray-600">
                  Professional academic writing, project development, and presentation services to support your
                  educational journey.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Why Choose Wistudy Books Collections?</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="bg-blue-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-blue-600">1</span>
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Quality Assured</h3>
              <p className="text-gray-600 text-sm">
                All our materials are carefully curated and verified for accuracy and relevance.
              </p>
            </div>
            <div className="text-center">
              <div className="bg-green-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-green-600">2</span>
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Affordable Pricing</h3>
              <p className="text-gray-600 text-sm">
                We offer competitive prices with regular promotions to make education accessible.
              </p>
            </div>
            <div className="text-center">
              <div className="bg-purple-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-purple-600">3</span>
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Fast Delivery</h3>
              <p className="text-gray-600 text-sm">
                Quick response times and efficient delivery of digital materials and services.
              </p>
            </div>
            <div className="text-center">
              <div className="bg-orange-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                <span className="text-2xl font-bold text-orange-600">4</span>
              </div>
              <h3 className="font-bold text-gray-900 mb-2">Expert Support</h3>
              <p className="text-gray-600 text-sm">
                Professional customer service and academic guidance from experienced educators.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Contact CTA */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Start Your Educational Journey?</h2>
          <p className="text-xl mb-8">
            Join thousands of students who trust Wistudy Books Collections for their academic success.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="mailto:wistudybookscollections@gmail.com?subject=General%20Inquiry&body=Hi%20Wistudy%20Books%20Collections,%0A%0AI%20would%20like%20to%20learn%20more%20about%20your%20services.%0A%0AThank%20you!"
              target="_blank"
              rel="noreferrer"
              className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
            >
              Contact Us
            </a>
            <a
              href="https://t.me/+g_BCFCWVs9I5YWU0"
              target="_blank"
              rel="noreferrer"
              className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors"
            >
              Join Our Community
            </a>
          </div>
        </div>
      </section>
    </main>
  )
}
