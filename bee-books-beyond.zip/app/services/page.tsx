"use client"
import { Card, CardContent } from "@/components/ui/card"
import { FileText, Presentation, Briefcase, Clock, CheckCircle } from "lucide-react"

const academicServices = [
  {
    id: "term-paper",
    title: "Custom Term Paper Writing",
    icon: FileText,
    originalPrice: "₦1000",
    price: "₦700",
    description: "Professional term paper writing service for any topic or subject",
    features: [
      "Original content guaranteed",
      "Proper citations and references",
      "Academic formatting (APA, MLA, etc.)",
      "Plagiarism-free guarantee",
      "Unlimited revisions",
      "24-48 hours delivery",
    ],
    deliveryTime: "24-48 hours",
    category: "Academic Writing",
  },
  {
    id: "seminar",
    title: "Seminar Presentation Service",
    icon: Presentation,
    originalPrice: "₦15000",
    price: "₦10000",
    description: "Complete seminar preparation including slides, notes, and presentation materials",
    features: [
      "Professional PowerPoint slides",
      "Speaker notes included",
      "Research and content development",
      "Visual aids and graphics",
      "Q&A preparation",
      "Practice session guidance",
    ],
    deliveryTime: "3-5 days",
    category: "Presentation",
  },
  {
    id: "project",
    title: "Complete Project Development",
    icon: Briefcase,
    originalPrice: "₦50000",
    price: "Negotiable",
    description: "Full project development from concept to completion for academic or professional use",
    features: [
      "Project planning and design",
      "Research and analysis",
      "Implementation guidance",
      "Documentation and reports",
      "Presentation materials",
      "Ongoing support",
    ],
    deliveryTime: "1-2 weeks",
    category: "Project Development",
  },
]

export default function ServicesPage() {
  return (
    <main className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-purple-100 to-blue-100 py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Academic Services</h1>
          <p className="text-xl text-gray-700 mb-6">Professional academic writing and project development services</p>
          <div className="flex justify-center">
            <div className="bg-white p-6 rounded-lg shadow-lg">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Why Choose Our Services?</h3>
              <div className="flex items-center justify-center space-x-6 text-sm text-gray-600">
                <div className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                  <span>100% Original</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                  <span>On-Time Delivery</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                  <span>Professional Quality</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Ad after hero */}

      {/* Services Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Our Academic Services</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {academicServices.map((service) => {
              const IconComponent = service.icon

              // Define the mailto links for each service
              let mailtoLink = ""
              let buttonText = ""

              if (service.id === "term-paper") {
                mailtoLink =
                  "mailto:wistudybookscollections@gmail.com?subject=Term%20Paper%20Writing%20Service&body=Hi%20Wistudy%20Books%20Collections,%0A%0AI'm%20interested%20in%20your%20Custom%20Term%20Paper%20Writing%20service%20for%20₦700.%20Please%20share%20the%20next%20steps%20and%20requirements.%0A%0AThank%20you!"
                buttonText = "Request Term Paper Service"
              } else if (service.id === "seminar") {
                mailtoLink =
                  "mailto:wistudybookscollections@gmail.com?subject=Presentation%20Service%20Request&body=Hi%20Wistudy%20Books%20Collections,%0A%0AI'm%20interested%20in%20your%20Presentation%20Service%20for%20₦10,000.%20Please%20let%20me%20know%20how%20to%20proceed%20with%20booking%20and%20delivery.%0A%0AThanks!"
                buttonText = "Request Presentation Service"
              } else if (service.id === "project") {
                mailtoLink =
                  "mailto:wistudybookscollections@gmail.com?subject=Project%20Development%20Request&body=Hi%20Wistudy%20Books%20Collections,%0A%0AI'm%20interested%20in%20the%20Complete%20Project%20Development%20service%20you%20offer.%20I%20would%20like%20to%20discuss%20pricing%20and%20next%20steps%20to%20get%20started.%0A%0AThank%20you!"
                buttonText = "Request Project Development"
              }

              return (
                <Card
                  key={service.id}
                  className="group hover:shadow-xl transition-all duration-300 border-2 hover:border-purple-200"
                >
                  <CardContent className="p-8">
                    <div className="text-center mb-6">
                      <div className="inline-flex items-center justify-center w-16 h-16 bg-purple-100 rounded-full mb-4">
                        <IconComponent className="w-8 h-8 text-purple-600" />
                      </div>
                      <h3 className="text-2xl font-bold text-gray-900 mb-2">{service.title}</h3>
                      <span className="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm font-medium">
                        {service.category}
                      </span>
                    </div>

                    <p className="text-gray-600 mb-6 text-center">{service.description}</p>

                    <div className="mb-6">
                      <h4 className="font-semibold text-gray-900 mb-3">What's Included:</h4>
                      <ul className="space-y-2">
                        {service.features.map((feature, index) => (
                          <li key={index} className="flex items-start">
                            <CheckCircle className="w-4 h-4 text-green-600 mr-2 mt-0.5 flex-shrink-0" />
                            <span className="text-sm text-gray-600">{feature}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="flex items-center justify-center mb-6">
                      <Clock className="w-4 h-4 text-gray-500 mr-2" />
                      <span className="text-sm text-gray-600">Delivery: {service.deliveryTime}</span>
                    </div>

                    <div className="text-center mb-6">
                      <div className="flex items-center justify-center gap-3">
                        <span className="text-lg text-gray-500 line-through">{service.originalPrice}</span>
                        <span
                          className={`text-3xl font-bold ${service.price === "Negotiable" ? "text-blue-600" : "text-red-600"}`}
                        >
                          {service.price}
                        </span>
                        {service.price !== "Negotiable" && (
                          <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs font-bold">
                            PROMO!
                          </span>
                        )}
                      </div>
                      {service.id === "term-paper" && <p className="text-sm text-gray-500 mt-1">Per topic</p>}
                    </div>

                    <a
                      href={mailtoLink}
                      target="_blank"
                      rel="noreferrer"
                      className="w-full bg-purple-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-purple-700 transition-colors duration-300 block text-center"
                    >
                      {buttonText}
                    </a>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Ad between sections */}

      {/* How It Works Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">How It Works</h2>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 bg-purple-600 text-white rounded-full font-bold text-lg mb-4">
                1
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Choose Service</h3>
              <p className="text-gray-600 text-sm">Select the academic service you need from our offerings</p>
            </div>

            <div className="text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 bg-purple-600 text-white rounded-full font-bold text-lg mb-4">
                2
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Send Request</h3>
              <p className="text-gray-600 text-sm">Click the button to send us your detailed requirements via email</p>
            </div>

            <div className="text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 bg-purple-600 text-white rounded-full font-bold text-lg mb-4">
                3
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Get Quote</h3>
              <p className="text-gray-600 text-sm">Receive a detailed quote and timeline for your project</p>
            </div>

            <div className="text-center">
              <div className="inline-flex items-center justify-center w-12 h-12 bg-purple-600 text-white rounded-full font-bold text-lg mb-4">
                4
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Receive Work</h3>
              <p className="text-gray-600 text-sm">Get your completed work delivered on time with quality guarantee</p>
            </div>
          </div>
        </div>
      </section>

      {/* Ad before contact */}

      {/* Contact Section */}
      <section className="py-16 bg-purple-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Need Custom Academic Help?</h2>
          <p className="text-xl mb-8">Contact us directly for personalized academic assistance</p>
          <a
            href="mailto:wistudybookscollections@gmail.com?subject=Custom%20Academic%20Service%20Inquiry&body=Hi%20Wistudy%20Books%20Collections,%0A%0AI%20need%20custom%20academic%20assistance.%20Please%20contact%20me%20to%20discuss%20my%20requirements.%0A%0AThank%20you!"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center justify-center bg-white text-purple-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors duration-300"
          >
            Contact Us Now
          </a>
        </div>
      </section>

      {/* Final ad */}
    </main>
  )
}
