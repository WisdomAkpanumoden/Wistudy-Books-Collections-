import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { BookOpen, Stethoscope, Briefcase, History, Laptop, GraduationCap } from "lucide-react"

const categories = [
  {
    id: "medical",
    name: "Medical & Health",
    icon: Stethoscope,
    description: "Medical textbooks, anatomy guides, and health science materials",
    count: "15+ books",
    color: "bg-red-100 text-red-600",
    featured: ["Ross and Wilson Anatomy and Physiology", "Medical Terminology Guide"],
  },
  {
    id: "business",
    name: "Business & Leadership",
    icon: Briefcase,
    description: "Business strategy, leadership, and entrepreneurship books",
    count: "12+ books",
    color: "bg-blue-100 text-blue-600",
    featured: ["Start the Work", "Team Work"],
  },
  {
    id: "education",
    name: "Education & Certification",
    icon: GraduationCap,
    description: "NPCE materials, certification guides, and educational resources",
    count: "20+ materials",
    color: "bg-green-100 text-green-600",
    featured: ["NPCE Past Questions", "Subject-Specific Materials"],
  },
  {
    id: "history",
    name: "History & Culture",
    icon: History,
    description: "Historical texts, cultural studies, and heritage materials",
    count: "8+ books",
    color: "bg-purple-100 text-purple-600",
    featured: ["Black History", "Cultural Heritage Studies"],
  },
  {
    id: "technology",
    name: "Technology & Innovation",
    icon: Laptop,
    description: "Digital innovation, technology trends, and IT resources",
    count: "10+ books",
    color: "bg-orange-100 text-orange-600",
    featured: ["Digital Innovation", "Tech Leadership"],
  },
  {
    id: "general",
    name: "General Studies",
    icon: BookOpen,
    description: "Diverse collection of academic and reference materials",
    count: "25+ books",
    color: "bg-gray-100 text-gray-600",
    featured: ["Academic Writing", "Research Methods"],
  },
]

export default function CategoriesPage() {
  return (
    <main className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-indigo-100 to-purple-100 py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Book Categories</h1>
          <p className="text-xl text-gray-700">Explore our comprehensive collection organized by subject areas</p>
        </div>
      </div>

      {/* Categories Grid */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {categories.map((category) => {
              const IconComponent = category.icon

              return (
                <Card key={category.id} className="group hover:shadow-xl transition-all duration-300">
                  <CardContent className="p-8">
                    <div className="text-center mb-6">
                      <div
                        className={`inline-flex items-center justify-center w-16 h-16 rounded-full mb-4 ${category.color}`}
                      >
                        <IconComponent className="w-8 h-8" />
                      </div>
                      <h3 className="text-2xl font-bold text-gray-900 mb-2">{category.name}</h3>
                      <p className="text-gray-600 mb-4">{category.description}</p>
                      <span className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm font-medium">
                        {category.count}
                      </span>
                    </div>

                    <div className="mb-6">
                      <h4 className="font-semibold text-gray-900 mb-3">Featured Items:</h4>
                      <ul className="space-y-2">
                        {category.featured.map((item, index) => (
                          <li key={index} className="flex items-center text-sm text-gray-600">
                            <span className="w-2 h-2 bg-blue-400 rounded-full mr-3"></span>
                            {item}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <Link
                      href={`/search?category=${category.id}`}
                      className="w-full bg-gray-900 text-white py-3 px-6 rounded-lg font-semibold hover:bg-gray-800 transition-colors duration-300 block text-center"
                    >
                      Browse {category.name}
                    </Link>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        </div>
      </section>

      {/* Popular Categories */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Most Popular Categories</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="bg-green-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <GraduationCap className="w-10 h-10 text-green-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">NPCE Materials</h3>
              <p className="text-gray-600 mb-4">Most requested certification materials</p>
              <Link href="/npce" className="text-green-600 hover:text-green-700 font-semibold">
                View NPCE Materials →
              </Link>
            </div>
            <div className="text-center">
              <div className="bg-red-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Stethoscope className="w-10 h-10 text-red-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Medical Books</h3>
              <p className="text-gray-600 mb-4">Essential medical and health textbooks</p>
              <Link href="/search?category=medical" className="text-red-600 hover:text-red-700 font-semibold">
                Browse Medical Books →
              </Link>
            </div>
            <div className="text-center">
              <div className="bg-blue-100 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Briefcase className="w-10 h-10 text-blue-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Business Books</h3>
              <p className="text-gray-600 mb-4">Leadership and business strategy guides</p>
              <Link href="/search?category=business" className="text-blue-600 hover:text-blue-700 font-semibold">
                Browse Business Books →
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-indigo-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Can't Find What You're Looking For?</h2>
          <p className="text-xl mb-8">We're constantly adding new books and materials to our collection</p>
          <a
            href="mailto:wistudybookscollections@gmail.com?subject=Book%20Request&body=Hi%20Wistudy%20Books%20Collections,%0A%0AI'm%20looking%20for%20a%20specific%20book%20or%20material:%0A%0ATitle:%20%0AAuthor:%20%0ASubject:%20%0A%0APlease%20let%20me%20know%20if%20you%20can%20help.%0A%0AThank%20you!"
            target="_blank"
            rel="noreferrer"
            className="bg-white text-indigo-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
          >
            Request a Book
          </a>
        </div>
      </section>
    </main>
  )
}
