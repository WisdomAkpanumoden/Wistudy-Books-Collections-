import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { TelegramWidget } from "@/components/telegram-widget"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Wistudy Books Collections - Your Ultimate Study Partner",
  description:
    "Discover amazing books, NPCE materials, and professional academic services at Wistudy Books Collections. Quality educational resources for academic excellence.",
  keywords: "books, education, NPCE, pharmacy technician, academic services, study materials, Nigeria",
  authors: [{ name: "Wistudy Books Collections" }],
  creator: "Wistudy Books Collections",
  publisher: "Wistudy Books Collections",
  robots: "index, follow",
  openGraph: {
    title: "Wistudy Books Collections - Your Ultimate Study Partner",
    description: "Quality educational resources and academic services for students and professionals",
    url: "https://wistudy-books.vercel.app",
    siteName: "Wistudy Books Collections",
    type: "website",
    locale: "en_US",
  },
  twitter: {
    card: "summary_large_image",
    title: "Wistudy Books Collections",
    description: "Your Ultimate Study Partner for Academic Excellence",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head></head>
      <body className={inter.className}>
        <Header />
        {children}
        <Footer />
        <TelegramWidget />
      </body>
    </html>
  )
}
