"use client"

import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Star, BookOpen, Calendar } from "lucide-react"

const npceYearlyQuestions = [
  {
    id: "npce-2024",
    title: "NPCE 2024 Past Questions",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦2000",
    price: "₦1500",
    rating: 4.9,
    reviews: 89,
    image: "/images/npce-certificate.jpeg",
    category: "Education",
    year: "2024",
    description: "Complete set of 2024 pharmacy technician certification past questions",
  },
  {
    id: "npce-2023",
    title: "NPCE 2023 Past Questions",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦2000",
    price: "₦1500",
    rating: 4.8,
    reviews: 76,
    image: "/images/npce-certificate.jpeg",
    category: "Education",
    year: "2023",
    description: "Complete set of 2023 pharmacy technician certification past questions",
  },
  {
    id: "npce-2022",
    title: "NPCE 2022 Past Questions",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦2000",
    price: "₦1500",
    rating: 4.7,
    reviews: 65,
    image: "/images/npce-certificate.jpeg",
    category: "Education",
    year: "2022",
    description: "Complete set of 2022 pharmacy technician certification past questions",
  },
  {
    id: "npce-2021",
    title: "NPCE 2021 Past Questions",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦2000",
    price: "₦1500",
    rating: 4.6,
    reviews: 54,
    image: "/images/npce-certificate.jpeg",
    category: "Education",
    year: "2021",
    description: "Complete set of 2021 pharmacy technician certification past questions",
  },
  {
    id: "npce-2020",
    title: "NPCE 2020 Past Questions",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦2000",
    price: "₦1500",
    rating: 4.5,
    reviews: 48,
    image: "/images/npce-certificate.jpeg",
    category: "Education",
    year: "2020",
    description: "Complete set of 2020 pharmacy technician certification past questions",
  },
  {
    id: "npce-2019",
    title: "NPCE 2019 Past Questions",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦2000",
    price: "₦1500",
    rating: 4.4,
    reviews: 42,
    image: "/images/npce-certificate.jpeg",
    category: "Education",
    year: "2019",
    description: "Complete set of 2019 pharmacy technician certification past questions",
  },
  {
    id: "npce-2018",
    title: "NPCE 2018 Past Questions",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦2000",
    price: "₦1500",
    rating: 4.3,
    reviews: 38,
    image: "/images/npce-certificate.jpeg",
    category: "Education",
    year: "2018",
    description: "Complete set of 2018 pharmacy technician certification past questions",
  },
]

const npceSubjectQuestions = [
  {
    id: "npce-ana",
    title: "NPCE ANA (2018-2024)",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦3500",
    price: "₦1500",
    rating: 4.6,
    reviews: 43,
    image: "/images/npce-certificate.jpeg",
    category: "Education",
    subject: "Anatomy & Physiology",
    description: "Anatomy & Physiology past questions from 2018 to 2024",
  },
  {
    id: "npce-eng",
    title: "NPCE ENG (2018-2024)",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦3500",
    price: "₦1500",
    rating: 4.7,
    reviews: 38,
    image: "/images/npce-certificate.jpeg",
    category: "Education",
    subject: "English Language",
    description: "English Language past questions from 2018 to 2024",
  },
  {
    id: "npce-ptp",
    title: "NPCE PTP (2018-2024)",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦3500",
    price: "₦1500",
    rating: 4.5,
    reviews: 35,
    image: "/images/npce-certificate.jpeg",
    category: "Education",
    subject: "Pharmacy Technician Practice",
    description: "Pharmacy Technician Practice past questions from 2018 to 2024",
  },
  {
    id: "npce-aum",
    title: "NPCE AUM (2018-2024)",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦3500",
    price: "₦1500",
    rating: 4.4,
    reviews: 32,
    image: "/images/npce-certificate.jpeg",
    category: "Education",
    subject: "Arithmetic & Unit of Measurement",
    description: "Arithmetic & Unit of Measurement past questions from 2018 to 2024",
  },
  {
    id: "npce-mcb",
    title: "NPCE MCB (2018-2024)",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦3500",
    price: "₦1500",
    rating: 4.6,
    reviews: 29,
    image: "/images/npce-certificate.jpeg",
    category: "Education",
    subject: "Microbiology",
    description: "Microbiology past questions from 2018 to 2024",
  },
  {
    id: "npce-bdt",
    title: "NPCE BDT (2018-2024)",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦3500",
    price: "₦1500",
    rating: 4.5,
    reviews: 26,
    image: "/images/npce-certificate.jpeg",
    category: "Education",
    subject: "Basic Drug Therapy",
    description: "Basic Drug Therapy past questions from 2018 to 2024",
  },
]

export default function NPCEPage() {
  const handlePurchase = (item: any) => {
    const subject = `Purchase Request: ${item.title}`
    const body = `Hi Wistudy Books Collections,

I want to purchase "${item.title}" by ${item.author} for the promotional price of ${item.price} (originally ${item.originalPrice}).

Please let me know the next steps for completing this purchase.

Thank you!`
    window.location.href = `mailto:wistudybookscollections@gmail.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`
  }

  return (
    <main className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-blue-100 to-green-100 py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Pharmacy Technician Certification Past Questions</h1>
          <p className="text-xl text-gray-700 mb-6">National Pre-Certificate Examination (NPCE) Materials</p>
          <div className="flex justify-center">
            <Image
              src="/images/npce-certificate.jpeg"
              alt="NPCE Certificate"
              width={400}
              height={300}
              className="rounded-lg shadow-lg"
            />
          </div>
        </div>
      </div>

      {/* Ad after hero */}

      {/* Pricing Info */}
      <div className="py-8 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <div className="text-center p-6 bg-blue-50 rounded-lg">
              <Calendar className="w-12 h-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">Per Year</h3>
              <p className="text-gray-600 mb-4">Complete set of questions for entire year</p>
              <div className="flex items-center justify-center gap-2">
                <span className="text-lg text-gray-500 line-through">₦2000</span>
                <span className="text-2xl font-bold text-blue-600">₦1500</span>
              </div>
            </div>
            <div className="text-center p-6 bg-green-50 rounded-lg">
              <BookOpen className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <h3 className="text-xl font-bold text-gray-900 mb-2">Per Subject</h3>
              <p className="text-gray-600 mb-4">Questions for specific subject (2018-2024)</p>
              <div className="flex items-center justify-center gap-2">
                <span className="text-lg text-gray-500 line-through">₦3500</span>
                <span className="text-2xl font-bold text-green-600">₦1500</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Ad after pricing */}

      {/* Yearly Questions */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Past Questions by Year</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {npceYearlyQuestions.map((item) => (
              <Card key={item.id} className="group hover:shadow-lg transition-shadow duration-300">
                <CardContent className="p-6">
                  <div className="relative mb-4">
                    <Image
                      src={item.image || "/placeholder.svg"}
                      alt={item.title}
                      width={200}
                      height={300}
                      className="w-full h-64 object-cover rounded-lg"
                    />
                    <span className="absolute top-2 right-2 bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">
                      {item.year}
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                    {item.title}
                  </h3>

                  <p className="text-gray-600 mb-3">by {item.author}</p>

                  <div className="flex items-center mb-4">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < Math.floor(item.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-gray-600 ml-2">
                      {item.rating} ({item.reviews} reviews)
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex flex-col">
                      <span className="text-sm text-gray-500 line-through">{item.originalPrice}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-2xl font-bold text-blue-600">{item.price}</span>
                        <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-bold">
                          PROMO!
                        </span>
                      </div>
                    </div>
                    <a
                      href={`mailto:wistudybookscollections@gmail.com?subject=Purchase%20Request:%20${encodeURIComponent(item.title)}&body=Hi%20Wistudy%20Books%20Collections,%0A%0AI%20want%20to%20purchase%20%22${encodeURIComponent(item.title)}%22%20by%20${encodeURIComponent(item.author)}%20for%20the%20promotional%20price%20of%20${encodeURIComponent(item.price)}%20(originally%20${encodeURIComponent(item.originalPrice)}).%0A%0APlease%20let%20me%20know%20the%20next%20steps%20for%20completing%20this%20purchase.%0A%0AThank%20you!`}
                      target="_blank"
                      className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-blue-600 text-white hover:bg-blue-700 h-10 px-4 py-2"
                      rel="noreferrer"
                    >
                      Buy Now
                    </a>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Ad between sections */}

      {/* Subject Questions */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Past Questions by Subject</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {npceSubjectQuestions.map((item) => (
              <Card key={item.id} className="group hover:shadow-lg transition-shadow duration-300">
                <CardContent className="p-6">
                  <div className="relative mb-4">
                    <Image
                      src={item.image || "/placeholder.svg"}
                      alt={item.title}
                      width={200}
                      height={300}
                      className="w-full h-64 object-cover rounded-lg"
                    />
                    <span className="absolute top-2 right-2 bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">
                      Subject
                    </span>
                  </div>

                  <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-green-600 transition-colors">
                    {item.title}
                  </h3>

                  <p className="text-gray-600 mb-2">by {item.author}</p>
                  <p className="text-sm text-gray-500 mb-3">{item.subject}</p>

                  <div className="flex items-center mb-4">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < Math.floor(item.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-gray-600 ml-2">
                      {item.rating} ({item.reviews} reviews)
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <div className="flex flex-col">
                      <span className="text-sm text-gray-500 line-through">{item.originalPrice}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-2xl font-bold text-green-600">{item.price}</span>
                        <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-bold">
                          PROMO!
                        </span>
                      </div>
                    </div>
                    <a
                      href={`mailto:wistudybookscollections@gmail.com?subject=Purchase%20Request:%20${encodeURIComponent(item.title)}&body=Hi%20Wistudy%20Books%20Collections,%0A%0AI%20want%20to%20purchase%20%22${encodeURIComponent(item.title)}%22%20by%20${encodeURIComponent(item.author)}%20for%20the%20promotional%20price%20of%20${encodeURIComponent(item.price)}%20(originally%20${encodeURIComponent(item.originalPrice)}).%0A%0APlease%20let%20me%20know%20the%20next%20steps%20for%20completing%20this%20purchase.%0A%0AThank%20you!`}
                      target="_blank"
                      className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-green-600 text-white hover:bg-green-700 h-10 px-4 py-2"
                      rel="noreferrer"
                    >
                      Buy Now
                    </a>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Final ad */}
    </main>
  )
}
