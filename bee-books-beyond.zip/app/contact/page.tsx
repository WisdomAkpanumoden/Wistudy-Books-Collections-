import { Card, CardContent } from "@/components/ui/card"
import { Mail, MessageCircle, Clock, MapPin } from "lucide-react"

export default function ContactPage() {
  return (
    <main className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-green-100 to-blue-100 py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Contact Us</h1>
          <p className="text-xl text-gray-700">
            Get in touch with our team for any questions, orders, or academic assistance
          </p>
        </div>
      </div>

      {/* Contact Methods */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">How to Reach Us</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Email */}
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <Mail className="w-12 h-12 text-blue-600 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-gray-900 mb-4">Email Us</h3>
                <p className="text-gray-600 mb-4">Send us your questions, orders, or requests</p>
                <a
                  href="mailto:wistudybookscollections@gmail.com"
                  className="text-blue-600 hover:text-blue-700 font-semibold"
                >
                  wistudybookscollections@gmail.com
                </a>
                <div className="mt-4">
                  <a
                    href="mailto:wistudybookscollections@gmail.com?subject=General%20Inquiry&body=Hi%20Wistudy%20Books%20Collections,%0A%0A[Your%20message%20here]%0A%0AThank%20you!"
                    target="_blank"
                    rel="noreferrer"
                    className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors inline-block"
                  >
                    Send Email
                  </a>
                </div>
              </CardContent>
            </Card>

            {/* Telegram */}
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <MessageCircle className="w-12 h-12 text-green-600 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-gray-900 mb-4">Join Our Community</h3>
                <p className="text-gray-600 mb-4">Connect with other students and get updates</p>
                <p className="text-green-600 font-semibold mb-4">Telegram Group</p>
                <a
                  href="https://t.me/+g_BCFCWVs9I5YWU0"
                  target="_blank"
                  rel="noreferrer"
                  className="bg-green-600 text-white px-6 py-2 rounded-lg hover:bg-green-700 transition-colors inline-block"
                >
                  Join Group
                </a>
              </CardContent>
            </Card>

            {/* Response Time */}
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-8">
                <Clock className="w-12 h-12 text-purple-600 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-gray-900 mb-4">Response Time</h3>
                <p className="text-gray-600 mb-4">We typically respond within</p>
                <p className="text-purple-600 font-semibold text-lg">2-6 hours</p>
                <p className="text-sm text-gray-500 mt-2">During business hours</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Quick Contact Options */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Quick Contact Options</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <a
              href="mailto:wistudybookscollections@gmail.com?subject=Book%20Order&body=Hi,%0A%0AI%20would%20like%20to%20order%20a%20book.%0A%0ABook%20Title:%20%0AAuthor:%20%0A%0AThank%20you!"
              target="_blank"
              rel="noreferrer"
              className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow text-center"
            >
              <h3 className="font-bold text-gray-900 mb-2">Order Books</h3>
              <p className="text-gray-600 text-sm">Quick book ordering</p>
            </a>
            <a
              href="mailto:wistudybookscollections@gmail.com?subject=NPCE%20Materials&body=Hi,%0A%0AI%20need%20NPCE%20materials.%0A%0AYear/Subject:%20%0A%0AThank%20you!"
              target="_blank"
              rel="noreferrer"
              className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow text-center"
            >
              <h3 className="font-bold text-gray-900 mb-2">NPCE Materials</h3>
              <p className="text-gray-600 text-sm">Certification resources</p>
            </a>
            <a
              href="mailto:wistudybookscollections@gmail.com?subject=Academic%20Services&body=Hi,%0A%0AI%20need%20academic%20assistance.%0A%0AService%20Type:%20%0ADetails:%20%0A%0AThank%20you!"
              target="_blank"
              rel="noreferrer"
              className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow text-center"
            >
              <h3 className="font-bold text-gray-900 mb-2">Academic Services</h3>
              <p className="text-gray-600 text-sm">Writing & projects</p>
            </a>
            <a
              href="mailto:wistudybookscollections@gmail.com?subject=General%20Support&body=Hi,%0A%0AI%20have%20a%20question.%0A%0A[Your%20question%20here]%0A%0AThank%20you!"
              target="_blank"
              rel="noreferrer"
              className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow text-center"
            >
              <h3 className="font-bold text-gray-900 mb-2">General Support</h3>
              <p className="text-gray-600 text-sm">Any other questions</p>
            </a>
          </div>
        </div>
      </section>

      {/* Business Hours */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="text-3xl font-bold text-gray-900 mb-8">Business Information</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <Clock className="w-8 h-8 text-blue-600 mx-auto mb-4" />
                <h3 className="font-bold text-gray-900 mb-2">Business Hours</h3>
                <p className="text-gray-600">Monday - Friday: 8:00 AM - 6:00 PM</p>
                <p className="text-gray-600">Saturday: 9:00 AM - 4:00 PM</p>
                <p className="text-gray-600">Sunday: Closed</p>
              </div>
              <div>
                <MapPin className="w-8 h-8 text-green-600 mx-auto mb-4" />
                <h3 className="font-bold text-gray-900 mb-2">Location</h3>
                <p className="text-gray-600">Lagos, Nigeria</p>
                <p className="text-gray-600">Serving customers nationwide</p>
                <p className="text-gray-600">Digital delivery available</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Preview */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
          <p className="text-xl mb-8">Common questions about our services and ordering process</p>
          <a
            href="/faq"
            className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors inline-block"
          >
            View FAQ
          </a>
        </div>
      </section>
    </main>
  )
}
