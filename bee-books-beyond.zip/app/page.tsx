import { Hero } from "@/components/hero"
import { FeaturedBooks } from "@/components/featured-books"
import { BookSlideshow } from "@/components/book-slideshow"
import { SearchSection } from "@/components/search-section"

export default function HomePage() {
  return (
    <main>
      <Hero />

      <BookSlideshow />

      <SearchSection />

      <FeaturedBooks />
    </main>
  )
}
