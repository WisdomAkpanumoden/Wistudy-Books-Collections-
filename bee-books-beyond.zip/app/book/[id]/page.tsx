"use client"

import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Star, ArrowLeft } from "lucide-react"
import Link from "next/link"

const bookDetails = {
  1: {
    title: "Start the Work",
    author: "Natalie Dawson",
    originalPrice: "$24.99",
    price: "$2.99",
    rating: 4.8,
    reviews: 127,
    image: "/images/start-the-work.jpeg",
    category: "Business",
    description:
      "Learn how to duplicate yourself and scale your business with this comprehensive guide. Natalie Dawson provides practical strategies for building systems, delegating effectively, and creating sustainable growth in your business ventures.",
    features: [
      "Business scaling strategies",
      "Delegation frameworks",
      "System building techniques",
      "Leadership development insights",
      "Real-world case studies",
    ],
    pages: 284,
    publisher: "Business Excellence Press",
    isbn: "978-1-234567-89-0",
  },
  2: {
    title: "Team Work",
    author: "Natalie Dawson",
    originalPrice: "$26.99",
    price: "$2.00",
    rating: 4.9,
    reviews: 203,
    image: "/images/team-work.jpeg",
    category: "Business",
    description:
      "Master the art of building high-performance teams with this comprehensive guide. Learn proven strategies for improving team dynamics, communication, and productivity in any organization.",
    features: [
      "Team building strategies",
      "Communication frameworks",
      "Conflict resolution techniques",
      "Performance optimization",
      "Leadership development",
    ],
    pages: 312,
    publisher: "Business Excellence Press",
    isbn: "978-1-234567-90-6",
  },
  3: {
    title: "Black History",
    author: "Martin Luther King Jr.",
    originalPrice: "$29.99",
    price: "$2.50",
    rating: 4.9,
    reviews: 203,
    image: "/images/black-history.jpeg",
    category: "History",
    description:
      "An essential guide to understanding our shared heritage and the profound impact of Black history on modern society. This comprehensive work explores key events, figures, and movements that have shaped our world.",
    features: [
      "Comprehensive historical timeline",
      "Biographical profiles of key figures",
      "Cultural impact analysis",
      "Primary source documents",
      "Discussion questions for reflection",
    ],
    pages: 456,
    publisher: "Heritage Academic Press",
    isbn: "978-1-234567-91-3",
  },
}

export default function BookDetailPage({ params }: { params: { id: string } }) {
  const bookId = Number.parseInt(params.id)
  const book = bookDetails[bookId as keyof typeof bookDetails]

  if (!book) {
    return (
      <main className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Book Not Found</h1>
          <Link href="/books">
            <Button>Browse All Books</Button>
          </Link>
        </div>
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4">
        <Link href="/books" className="inline-flex items-center text-blue-600 hover:text-blue-700 mb-8">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Books
        </Link>

        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 p-8">
            {/* Book Image */}
            <div className="flex justify-center">
              <Image
                src={book.image || "/placeholder.svg"}
                alt={book.title}
                width={350}
                height={500}
                className="rounded-lg shadow-md"
              />
            </div>

            {/* Book Details */}
            <div>
              <div className="mb-4">
                <span className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
                  {book.category}
                </span>
              </div>

              <h1 className="text-4xl font-bold text-gray-900 mb-4">{book.title}</h1>

              <p className="text-xl text-gray-700 mb-6">by {book.author}</p>

              <div className="flex items-center mb-6">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`w-5 h-5 ${
                        i < Math.floor(book.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                      }`}
                    />
                  ))}
                </div>
                <span className="text-lg text-gray-600 ml-3">
                  {book.rating} ({book.reviews} reviews)
                </span>
              </div>

              <div className="mb-8">
                <div className="flex items-center gap-3">
                  <span className="text-2xl text-gray-500 line-through">{book.originalPrice}</span>
                  <span className="text-4xl font-bold text-red-600">{book.price}</span>
                  <span className="bg-red-100 text-red-800 px-3 py-1 rounded-full text-sm font-bold">PROMO!</span>
                </div>
              </div>

              <a
                href={`mailto:wistudybookscollections@gmail.com?subject=Book%20Purchase%20Request&body=Hi%20Wistudy%20Books%20Collections,%0A%0AI%20want%20to%20purchase%20%22${encodeURIComponent(book.title)}%22%20by%20${encodeURIComponent(book.author)}%20for%20the%20promotional%20price%20of%20${encodeURIComponent(book.price)}%20(originally%20${encodeURIComponent(book.originalPrice)}).%0A%0APlease%20let%20me%20know%20the%20next%20steps%20for%20completing%20this%20purchase.%0A%0AThank%20you!`}
                target="_blank"
                className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-blue-600 text-white hover:bg-blue-700 text-lg px-8 py-3 w-full md:w-auto mb-8"
                rel="noreferrer"
              >
                Buy Now via Email
              </a>

              <div className="border-t pt-8">
                <h3 className="text-xl font-bold text-gray-900 mb-4">Book Details</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="font-medium text-gray-700">Pages:</span>
                    <span className="text-gray-600 ml-2">{book.pages}</span>
                  </div>
                  <div>
                    <span className="font-medium text-gray-700">Publisher:</span>
                    <span className="text-gray-600 ml-2">{book.publisher}</span>
                  </div>
                  <div className="col-span-2">
                    <span className="font-medium text-gray-700">ISBN:</span>
                    <span className="text-gray-600 ml-2">{book.isbn}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Description and Features */}
          <div className="border-t bg-gray-50 p-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Description</h3>
                <p className="text-gray-700 leading-relaxed">{book.description}</p>
              </div>

              <div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">What You'll Learn</h3>
                <ul className="space-y-2">
                  {book.features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <span className="text-blue-600 mr-2">•</span>
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
  )
}
