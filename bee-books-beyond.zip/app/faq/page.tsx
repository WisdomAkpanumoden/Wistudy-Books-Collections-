"use client"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { ChevronDown, ChevronUp } from "lucide-react"

const faqData = [
  {
    category: "General",
    questions: [
      {
        question: "What is Wistudy Books Collections?",
        answer:
          "Wistudy Books Collections is your ultimate study partner providing quality educational books, NPCE materials, and professional academic services to students and professionals.",
      },
      {
        question: "How do I place an order?",
        answer:
          "Simply click the 'Buy Now' button on any book or service, and you'll be directed to send us an email with your order details. We'll respond with payment instructions and delivery information.",
      },
      {
        question: "What payment methods do you accept?",
        answer:
          "We accept various payment methods including bank transfers, mobile money, and other secure payment options. Payment details will be provided when you contact us.",
      },
      {
        question: "How long does delivery take?",
        answer:
          "Digital materials are delivered within 2-6 hours after payment confirmation. Physical books may take 1-3 business days depending on your location.",
      },
    ],
  },
  {
    category: "Books & Materials",
    questions: [
      {
        question: "Are your books original?",
        answer:
          "Yes, all our books are authentic and sourced from reputable publishers. We guarantee the quality and authenticity of all our educational materials.",
      },
      {
        question: "Can I get a refund if I'm not satisfied?",
        answer:
          "We offer a satisfaction guarantee. If you're not happy with your purchase, contact us within 7 days and we'll work to resolve any issues.",
      },
      {
        question: "Do you offer bulk discounts?",
        answer:
          "Yes, we offer special pricing for bulk orders and institutional purchases. Contact us directly to discuss your requirements.",
      },
      {
        question: "Are the books available in digital format?",
        answer:
          "Many of our books are available in both digital and physical formats. Digital versions are delivered instantly via email.",
      },
    ],
  },
  {
    category: "NPCE Materials",
    questions: [
      {
        question: "What NPCE materials do you offer?",
        answer:
          "We offer complete NPCE past questions by year (2018-2024) and subject-specific materials including ANA, ENG, PTP, AUM, MCB, and BDT.",
      },
      {
        question: "Are the NPCE questions up to date?",
        answer:
          "Yes, our NPCE materials are regularly updated and include the most recent past questions and relevant study materials.",
      },
      {
        question: "How much do NPCE materials cost?",
        answer:
          "Yearly past questions are ₦1,500 (originally ₦2,000) and subject-specific materials are ₦1,500 (originally ₦3,500).",
      },
      {
        question: "Do you provide answers to the questions?",
        answer:
          "Yes, our NPCE materials include both questions and detailed answers/explanations to help you understand the concepts.",
      },
    ],
  },
  {
    category: "Academic Services",
    questions: [
      {
        question: "What academic services do you provide?",
        answer:
          "We offer custom term paper writing (₦700), seminar presentation services (₦10,000), and complete project development (negotiable pricing).",
      },
      {
        question: "How long does it take to complete academic work?",
        answer:
          "Term papers: 24-48 hours, Seminar presentations: 3-5 days, Complete projects: 1-2 weeks. Timeline depends on complexity and requirements.",
      },
      {
        question: "Are your academic services original?",
        answer: "All our academic work is 100% original, plagiarism-free, and tailored to your specific requirements.",
      },
      {
        question: "Can you handle urgent requests?",
        answer:
          "Yes, we can accommodate urgent requests. Contact us directly to discuss timeline and any additional fees for rush orders.",
      },
    ],
  },
]

export default function FAQPage() {
  const [openItems, setOpenItems] = useState<string[]>([])

  const toggleItem = (id: string) => {
    setOpenItems((prev) => (prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]))
  }

  return (
    <main className="min-h-screen bg-gray-50">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-purple-100 to-blue-100 py-16">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Frequently Asked Questions</h1>
          <p className="text-xl text-gray-700">
            Find answers to common questions about our books, services, and ordering process
          </p>
        </div>
      </div>

      {/* FAQ Content */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 max-w-4xl">
          {faqData.map((category, categoryIndex) => (
            <div key={category.category} className="mb-12">
              <h2 className="text-2xl font-bold text-gray-900 mb-6 border-b-2 border-blue-200 pb-2">
                {category.category}
              </h2>
              <div className="space-y-4">
                {category.questions.map((faq, questionIndex) => {
                  const itemId = `${categoryIndex}-${questionIndex}`
                  const isOpen = openItems.includes(itemId)

                  return (
                    <Card key={itemId} className="border border-gray-200">
                      <CardContent className="p-0">
                        <button
                          onClick={() => toggleItem(itemId)}
                          className="w-full p-6 text-left hover:bg-gray-50 transition-colors flex justify-between items-center"
                        >
                          <h3 className="font-semibold text-gray-900 pr-4">{faq.question}</h3>
                          {isOpen ? (
                            <ChevronUp className="w-5 h-5 text-gray-500 flex-shrink-0" />
                          ) : (
                            <ChevronDown className="w-5 h-5 text-gray-500 flex-shrink-0" />
                          )}
                        </button>
                        {isOpen && (
                          <div className="px-6 pb-6">
                            <p className="text-gray-700 leading-relaxed">{faq.answer}</p>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  )
                })}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Still Have Questions */}
      <section className="py-16 bg-blue-600 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Still Have Questions?</h2>
          <p className="text-xl mb-8">Can't find what you're looking for? We're here to help!</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="mailto:wistudybookscollections@gmail.com?subject=Question%20Not%20in%20FAQ&body=Hi%20Wistudy%20Books%20Collections,%0A%0AI%20have%20a%20question%20that%20wasn't%20answered%20in%20your%20FAQ:%0A%0A[Your%20question%20here]%0A%0AThank%20you!"
              target="_blank"
              rel="noreferrer"
              className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
            >
              Email Us
            </a>
            <a
              href="https://t.me/+g_BCFCWVs9I5YWU0"
              target="_blank"
              rel="noreferrer"
              className="border-2 border-white text-white px-8 py-3 rounded-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors"
            >
              Join Telegram Group
            </a>
          </div>
        </div>
      </section>
    </main>
  )
}
