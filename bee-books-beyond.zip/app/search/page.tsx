"use client"

import { Suspense } from "react"
import { useSearchParams } from "next/navigation"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Star } from "lucide-react"

const allBooks = [
  {
    id: 1,
    title: "Start the Work",
    author: "Natalie Dawson",
    originalPrice: "$24.99",
    price: "$2.99",
    rating: 4.8,
    reviews: 127,
    image: "/images/start-the-work.jpeg",
    category: "business",
    keywords: ["business", "scaling", "entrepreneurship", "productivity"],
  },
  {
    id: 2,
    title: "Team Work",
    author: "Natalie Dawson",
    originalPrice: "$26.99",
    price: "$2.00",
    rating: 4.9,
    reviews: 203,
    image: "/images/team-work.jpeg",
    category: "business",
    keywords: ["teamwork", "collaboration", "leadership", "business"],
  },
  {
    id: 3,
    title: "Black History",
    author: "Martin Luther King Jr.",
    originalPrice: "$29.99",
    price: "$2.50",
    rating: 4.9,
    reviews: 203,
    image: "/images/black-history.jpeg",
    category: "history",
    keywords: ["history", "culture", "heritage", "education"],
  },
  {
    id: 23,
    title: "Ross and Wilson Anatomy and Physiology in Health and Illness",
    author: "Anne Waugh & Allison Grant",
    originalPrice: "₦1500",
    price: "₦1000",
    rating: 4.8,
    reviews: 156,
    image: "/images/anatomy-physiology.jpeg",
    category: "medical",
    keywords: ["anatomy", "physiology", "medical", "health", "illness", "textbook", "nursing", "medicine"],
  },
  {
    id: 4,
    title: "Digital Innovation",
    author: "Sarah Chen",
    originalPrice: "$34.99",
    price: "$2.99",
    rating: 4.7,
    reviews: 89,
    image: "/placeholder.svg?height=300&width=200",
    category: "technology",
    keywords: ["technology", "innovation", "digital", "future"],
  },
  {
    id: 5,
    title: "Creative Writing",
    author: "Emma Rodriguez",
    originalPrice: "$22.99",
    price: "$2.99",
    rating: 4.8,
    reviews: 94,
    image: "/placeholder.svg?height=300&width=200",
    category: "arts",
    keywords: ["writing", "creativity", "arts", "literature"],
  },
  {
    id: 6,
    title: "Financial Freedom",
    author: "Michael Thompson",
    originalPrice: "$31.99",
    price: "$3.99",
    rating: 4.7,
    reviews: 178,
    image: "/placeholder.svg?height=300&width=200",
    category: "finance",
    keywords: ["finance", "money", "investment", "wealth"],
  },
  // NPCE Yearly Past Questions
  {
    id: 10,
    title: "NPCE 2024 Past Questions",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦2000",
    price: "₦1500",
    rating: 4.9,
    reviews: 89,
    image: "/images/npce-certificate.jpeg",
    category: "education",
    keywords: ["npce", "pharmacy", "technician", "certification", "2024", "past questions"],
  },
  {
    id: 11,
    title: "NPCE 2023 Past Questions",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦2000",
    price: "₦1500",
    rating: 4.8,
    reviews: 76,
    image: "/images/npce-certificate.jpeg",
    category: "education",
    keywords: ["npce", "pharmacy", "technician", "certification", "2023", "past questions"],
  },
  {
    id: 12,
    title: "NPCE 2022 Past Questions",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦2000",
    price: "₦1500",
    rating: 4.7,
    reviews: 65,
    image: "/images/npce-certificate.jpeg",
    category: "education",
    keywords: ["npce", "pharmacy", "technician", "certification", "2022", "past questions"],
  },
  {
    id: 13,
    title: "NPCE 2021 Past Questions",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦2000",
    price: "₦1500",
    rating: 4.6,
    reviews: 54,
    image: "/images/npce-certificate.jpeg",
    category: "education",
    keywords: ["npce", "pharmacy", "technician", "certification", "2021", "past questions"],
  },
  {
    id: 14,
    title: "NPCE 2020 Past Questions",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦2000",
    price: "₦1500",
    rating: 4.5,
    reviews: 48,
    image: "/images/npce-certificate.jpeg",
    category: "education",
    keywords: ["npce", "pharmacy", "technician", "certification", "2020", "past questions"],
  },
  {
    id: 15,
    title: "NPCE 2019 Past Questions",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦2000",
    price: "₦1500",
    rating: 4.4,
    reviews: 42,
    image: "/images/npce-certificate.jpeg",
    category: "education",
    keywords: ["npce", "pharmacy", "technician", "certification", "2019", "past questions"],
  },
  {
    id: 16,
    title: "NPCE 2018 Past Questions",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦2000",
    price: "₦1500",
    rating: 4.3,
    reviews: 38,
    image: "/images/npce-certificate.jpeg",
    category: "education",
    keywords: ["npce", "pharmacy", "technician", "certification", "2018", "past questions"],
  },
  // NPCE Subject-Specific Questions
  {
    id: 17,
    title: "NPCE ANA (2018-2024)",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦3500",
    price: "₦1500",
    rating: 4.6,
    reviews: 43,
    image: "/images/npce-certificate.jpeg",
    category: "education",
    keywords: ["npce", "anatomy", "physiology", "ana", "pharmacy", "technician"],
  },
  {
    id: 18,
    title: "NPCE ENG (2018-2024)",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦3500",
    price: "₦1500",
    rating: 4.7,
    reviews: 38,
    image: "/images/npce-certificate.jpeg",
    category: "education",
    keywords: ["npce", "english", "language", "eng", "pharmacy", "technician"],
  },
  {
    id: 19,
    title: "NPCE PTP (2018-2024)",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦3500",
    price: "₦1500",
    rating: 4.5,
    reviews: 35,
    image: "/images/npce-certificate.jpeg",
    category: "education",
    keywords: ["npce", "pharmacy", "technician", "practice", "ptp"],
  },
  {
    id: 20,
    title: "NPCE AUM (2018-2024)",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦3500",
    price: "₦1500",
    rating: 4.4,
    reviews: 32,
    image: "/images/npce-certificate.jpeg",
    category: "education",
    keywords: ["npce", "arithmetic", "unit", "measurement", "aum", "pharmacy", "technician"],
  },
  {
    id: 21,
    title: "NPCE MCB (2018-2024)",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦3500",
    price: "₦1500",
    rating: 4.6,
    reviews: 29,
    image: "/images/npce-certificate.jpeg",
    category: "education",
    keywords: ["npce", "microbiology", "mcb", "pharmacy", "technician"],
  },
  {
    id: 22,
    title: "NPCE BDT (2018-2024)",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦3500",
    price: "₦1500",
    rating: 4.5,
    reviews: 26,
    image: "/images/npce-certificate.jpeg",
    category: "education",
    keywords: ["npce", "basic", "drug", "therapy", "bdt", "pharmacy", "technician"],
  },
]

function SearchResults() {
  const searchParams = useSearchParams()
  const query = searchParams.get("q") || ""
  const category = searchParams.get("category") || ""

  const filteredBooks = allBooks.filter((book) => {
    const matchesQuery =
      query === "" ||
      book.title.toLowerCase().includes(query.toLowerCase()) ||
      book.author.toLowerCase().includes(query.toLowerCase()) ||
      book.keywords.some((keyword) => keyword.toLowerCase().includes(query.toLowerCase()))

    const matchesCategory = category === "" || book.category === category

    return matchesQuery && matchesCategory
  })

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-4">Search Results</h1>
        {query && (
          <p className="text-gray-600">
            Showing results for: <span className="font-semibold">"{query}"</span>
          </p>
        )}
        {category && (
          <p className="text-gray-600">
            Category: <span className="font-semibold capitalize">{category}</span>
          </p>
        )}
        <p className="text-gray-600 mt-2">
          Found {filteredBooks.length} book{filteredBooks.length !== 1 ? "s" : ""}
        </p>
      </div>

      {filteredBooks.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-xl text-gray-600 mb-4">No books found matching your search.</p>
          <p className="text-gray-500">Try adjusting your search terms or browse all books.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredBooks.map((book) => (
            <Card key={book.id} className="group hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-6">
                <div className="relative mb-4">
                  <Image
                    src={book.image || "/placeholder.svg"}
                    alt={book.title}
                    width={200}
                    height={300}
                    className="w-full h-64 object-cover rounded-lg"
                  />
                  <span className="absolute top-2 right-2 bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium capitalize">
                    {book.category}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-gray-900 mb-2 group-hover:text-blue-600 transition-colors">
                  {book.title}
                </h3>

                <p className="text-gray-600 mb-3">by {book.author}</p>

                <div className="flex items-center mb-4">
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${
                          i < Math.floor(book.rating) ? "text-yellow-400 fill-current" : "text-gray-300"
                        }`}
                      />
                    ))}
                  </div>
                  <span className="text-sm text-gray-600 ml-2">
                    {book.rating} ({book.reviews} reviews)
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex flex-col">
                    <span className="text-sm text-gray-500 line-through">{book.originalPrice}</span>
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-bold text-red-600">{book.price}</span>
                      <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs font-bold">PROMO!</span>
                    </div>
                  </div>
                  <a
                    href={`mailto:wistudybookscollections@gmail.com?subject=Book%20Purchase%20Request&body=Hi%20Wistudy%20Books%20Collections,%0A%0AI%20want%20to%20purchase%20%22${encodeURIComponent(book.title)}%22%20by%20${encodeURIComponent(book.author)}%20for%20the%20promotional%20price%20of%20${encodeURIComponent(book.price)}%20(originally%20${encodeURIComponent(book.originalPrice)}).%0A%0APlease%20let%20me%20know%20the%20next%20steps%20for%20completing%20this%20purchase.%0A%0AThank%20you!`}
                    target="_blank"
                    className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-blue-600 text-white hover:bg-blue-700 h-10 px-4 py-2"
                    rel="noreferrer"
                  >
                    Buy Now
                  </a>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}

export default function SearchPage() {
  return (
    <main className="min-h-screen bg-gray-50">
      <Suspense fallback={<div className="container mx-auto px-4 py-8">Loading...</div>}>
        <SearchResults />
      </Suspense>
    </main>
  )
}
