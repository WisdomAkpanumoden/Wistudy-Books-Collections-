"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { ChevronLeft, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"

const slideshowBooks = [
  {
    id: 1,
    title: "Start the Work by Natalie Dawson",
    author: "Natalie Dawson",
    originalPrice: "$24.99",
    price: "$2.99",
    image: "/images/start-the-work.jpeg",
    description: "How to duplicate yourself and scale your business",
  },
  {
    id: 2,
    title: "Team Work by Natalie Dawson",
    author: "Natalie Dawson",
    originalPrice: "$26.99",
    price: "$2.00",
    image: "/images/team-work.jpeg",
    description: "How to build a high performance team",
  },
  {
    id: 3,
    title: "Black History by Martin Luther King Jr.",
    author: "Martin Luther King Jr.",
    originalPrice: "$29.99",
    price: "$2.50",
    image: "/images/black-history.jpeg",
    description: "An essential guide to understanding our shared heritage",
  },
  {
    id: 4,
    title: "NPCE 2024 Past Questions",
    author: "Pharmacist Council of Nigeria",
    originalPrice: "₦2000",
    price: "₦1500",
    image: "/images/npce-certificate.jpeg",
    description: "Complete pharmacy technician certification past questions",
  },
]

export function BookSlideshow() {
  const [currentSlide, setCurrentSlide] = useState(0)

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slideshowBooks.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [])

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slideshowBooks.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slideshowBooks.length) % slideshowBooks.length)
  }

  return (
    <section className="py-16 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Featured Books Collection</h2>

        <div className="relative max-w-6xl mx-auto">
          <div className="overflow-hidden rounded-lg bg-gradient-to-r from-blue-100 to-indigo-100">
            <div
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${currentSlide * 100}%)` }}
            >
              {slideshowBooks.map((book) => (
                <div key={book.id} className="w-full flex-shrink-0">
                  <div className="flex flex-col md:flex-row items-center p-8 md:p-12">
                    <div className="md:w-1/2 mb-8 md:mb-0">
                      <Image
                        src={book.image || "/placeholder.svg"}
                        alt={book.title}
                        width={300}
                        height={400}
                        className="mx-auto rounded-lg shadow-lg"
                      />
                    </div>
                    <div className="md:w-1/2 md:pl-12 text-center md:text-left">
                      <h3 className="text-3xl font-bold text-gray-900 mb-4">{book.title}</h3>
                      <p className="text-xl text-gray-700 mb-4">by {book.author}</p>
                      <p className="text-lg text-gray-600 mb-6">{book.description}</p>
                      <div className="flex items-center justify-center md:justify-start gap-4">
                        <div className="flex items-center gap-2">
                          <span className="text-lg text-gray-500 line-through">{book.originalPrice}</span>
                          <span className="text-2xl font-bold text-red-600">{book.price}</span>
                          <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full text-xs font-bold">
                            PROMO!
                          </span>
                        </div>
                        <a
                          href={`mailto:wistudybookscollections@gmail.com?subject=Book%20Purchase%20Request&body=Hi%20Wistudy%20Books%20Collections,%0A%0AI%20want%20to%20purchase%20%22${encodeURIComponent(book.title)}%22%20by%20${encodeURIComponent(book.author)}%20for%20the%20promotional%20price%20of%20${encodeURIComponent(book.price)}%20(originally%20${encodeURIComponent(book.originalPrice)}).%0A%0APlease%20let%20me%20know%20the%20next%20steps%20for%20completing%20this%20purchase.%0A%0AThank%20you!`}
                          target="_blank"
                          className="inline-flex items-center justify-center rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-blue-600 text-white hover:bg-blue-700 h-10 px-4 py-2"
                          rel="noreferrer"
                        >
                          Buy Now
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Navigation Buttons */}
          <Button
            variant="outline"
            size="icon"
            className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white"
            onClick={prevSlide}
          >
            <ChevronLeft className="w-4 h-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white"
            onClick={nextSlide}
          >
            <ChevronRight className="w-4 h-4" />
          </Button>

          {/* Slide Indicators */}
          <div className="flex justify-center mt-6 space-x-2">
            {slideshowBooks.map((_, index) => (
              <button
                key={index}
                className={`w-3 h-3 rounded-full transition-colors ${
                  index === currentSlide ? "bg-blue-600" : "bg-gray-300"
                }`}
                onClick={() => setCurrentSlide(index)}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
