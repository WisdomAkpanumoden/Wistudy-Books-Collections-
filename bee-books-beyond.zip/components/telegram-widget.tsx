import { MessageCircle } from "lucide-react"

export function TelegramWidget() {
  return (
    <div className="fixed bottom-6 right-6 z-50">
      <a
        href="https://t.me/+g_BCFCWVs9I5YWU0"
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center justify-center w-14 h-14 bg-blue-500 hover:bg-blue-600 text-white rounded-full shadow-lg transition-all duration-300 hover:scale-110 group"
        title="Join our Telegram group"
      >
        <MessageCircle className="w-6 h-6" />
        <div className="absolute right-16 top-1/2 transform -translate-y-1/2 bg-gray-900 text-white px-3 py-2 rounded-lg text-sm whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none">
          Join our Telegram group
        </div>
      </a>
    </div>
  )
}
