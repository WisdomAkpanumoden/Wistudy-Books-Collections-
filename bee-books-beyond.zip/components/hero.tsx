import { Button } from "@/components/ui/button"
import Link from "next/link"

export function Hero() {
  return (
    <section className="bg-gradient-to-br from-blue-50 to-indigo-100 py-20">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-blue-900 mb-6">Welcome to Wistudy Books Collections</h1>
          <p className="text-xl md:text-2xl text-blue-800 mb-8 leading-relaxed">
            Your ultimate study partner for academic excellence. Discover amazing books, NPCE materials, and
            professional academic services. Your educational success starts here!
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
              <Link href="/books">Browse All Books</Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="border-blue-600 text-blue-600 hover:bg-blue-50">
              <Link href="/services">Academic Services</Link>
            </Button>
            <Button asChild variant="outline" size="lg" className="border-blue-600 text-blue-600 hover:bg-blue-50">
              <Link href="/npce">NPCE Materials</Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  )
}
