export function WistudyBooksLogo() {
  return (
    <div className="relative w-10 h-10">
      <svg viewBox="0 0 40 40" className="w-full h-full" fill="none" xmlns="http://www.w3.org/2000/svg">
        {/* Background Circle */}
        <circle cx="20" cy="20" r="19" fill="#1e40af" stroke="#3b82f6" strokeWidth="2" />

        {/* Book Stack */}
        <rect x="8" y="22" width="24" height="4" fill="#fbbf24" rx="2" />
        <rect x="10" y="18" width="20" height="4" fill="#f59e0b" rx="2" />
        <rect x="12" y="14" width="16" height="4" fill="#d97706" rx="2" />

        {/* Graduation Cap */}
        <polygon points="20,8 14,12 26,12" fill="#1f2937" />
        <rect x="19" y="8" width="2" height="6" fill="#1f2937" />
        <circle cx="21" cy="8" r="1" fill="#fbbf24" />

        {/* Study Elements */}
        <rect x="15" y="25" width="10" height="1" fill="#3b82f6" rx="0.5" />
        <rect x="15" y="27" width="8" height="1" fill="#3b82f6" rx="0.5" />
        <rect x="15" y="29" width="6" height="1" fill="#3b82f6" rx="0.5" />

        {/* Pencil */}
        <rect x="28" y="16" width="2" height="8" fill="#fbbf24" rx="1" transform="rotate(45 29 20)" />
        <rect x="28.5" y="15.5" width="1" height="2" fill="#1f2937" transform="rotate(45 29 16.5)" />
      </svg>
    </div>
  )
}
